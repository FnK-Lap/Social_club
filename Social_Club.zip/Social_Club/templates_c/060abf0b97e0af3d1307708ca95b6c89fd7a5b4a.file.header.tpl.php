<?php /* Smarty version Smarty-3.1.18, created on 2014-05-28 14:53:56
         compiled from "views/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1585773073537de1a3000ec0-77031035%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '060abf0b97e0af3d1307708ca95b6c89fd7a5b4a' => 
    array (
      0 => 'views/header.tpl',
      1 => 1401281633,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1585773073537de1a3000ec0-77031035',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_537de1a30ef6e0_01043466',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_537de1a30ef6e0_01043466')) {function content_537de1a30ef6e0_01043466($_smarty_tpl) {?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="author" content="Blanqui Lucas, " >
		<meta name="description" content="social club" >
		<title>Social Club</title>
		<link rel="stylesheet" type="text/css" href="styles/login.css" >
		<link rel="stylesheet" type="text/css" href="styles/style.css">
		<link rel="stylesheet" type="text/css" href="styles/slick.css"/>
		<script src='libs/jQuery/jQuery.v1.11.1.js'></script>
		<script src='js/statuts.php'></script>
		<script type="text/javascript" src="js/formulaire.js"></script>
		<script type="text/javascript" src="//cdn.jsdelivr.net/jquery.slick/1.3.6/slick.min.js"></script>
	</head>	
	<body><?php }} ?>
