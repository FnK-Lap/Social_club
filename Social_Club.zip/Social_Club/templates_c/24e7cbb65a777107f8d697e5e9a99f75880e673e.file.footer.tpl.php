<?php /* Smarty version Smarty-3.1.18, created on 2014-05-27 15:05:54
         compiled from "views\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:39085384a9d218fda5-32398178%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '24e7cbb65a777107f8d697e5e9a99f75880e673e' => 
    array (
      0 => 'views\\footer.tpl',
      1 => 1400280465,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '39085384a9d218fda5-32398178',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5384a9d2192d58_15518162',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5384a9d2192d58_15518162')) {function content_5384a9d2192d58_15518162($_smarty_tpl) {?></body>
</html><?php }} ?>
