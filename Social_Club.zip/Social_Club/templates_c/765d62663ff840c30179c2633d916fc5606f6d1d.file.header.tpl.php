<?php /* Smarty version Smarty-3.1.18, created on 2014-05-27 15:57:10
         compiled from "views\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:76385384a9d1effb99-11023116%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '765d62663ff840c30179c2633d916fc5606f6d1d' => 
    array (
      0 => 'views\\header.tpl',
      1 => 1401205707,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '76385384a9d1effb99-11023116',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5384a9d1f3ca96_24301314',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5384a9d1f3ca96_24301314')) {function content_5384a9d1f3ca96_24301314($_smarty_tpl) {?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="author" content="Blanqui Lucas, " >
		<meta name="description" content="social club" >
		<title>Social Club</title>
		<link rel="stylesheet" type="text/css" href="styles/login.css" >
		<link rel="stylesheet" type="text/css" href="styles/style.css" >
		<script src='libs/jQuery/jQuery.v1.11.1.js'></script>
		<script src='js/statuts.php'></script>
		<script type="text/javascript" src="js/formulaire.js"></script>
	</head>	
	<body><?php }} ?>
