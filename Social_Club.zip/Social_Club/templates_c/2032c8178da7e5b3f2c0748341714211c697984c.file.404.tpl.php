<?php /* Smarty version Smarty-3.1.18, created on 2014-05-22 14:52:18
         compiled from "views/templates/404.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1604078832537df302d242c0-09362938%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2032c8178da7e5b3f2c0748341714211c697984c' => 
    array (
      0 => 'views/templates/404.tpl',
      1 => 1400714683,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1604078832537df302d242c0-09362938',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_537df302d63ed7_23768996',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_537df302d63ed7_23768996')) {function content_537df302d63ed7_23768996($_smarty_tpl) {?><header>
	<div id='title-logo-center'>
		Social<span class='title-color'>Club</span>
	</div>
	<div id='error-404'>
		<span class='404-message'>La page que vous avez demander n'est pas disponible.</span>
	</div>
</header><?php }} ?>
